#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	void  maxword(char  * s );
	float  mystof(char *str);
	void delestr(char * a ,char *b);
	int StrIndex(char *s,char *t);
	//7.1 
//	char *s="I am a students,She is a physician";
//	maxword(s);
	
	//7.2
//	char s[]="123.23";
//	float f=mystof(s);
//	printf("%f",f);

	//7.3
	char s[]="aaaabc";
	char t[]="bc";
	int index;
	index= StrIndex(s,t);
	printf("%d",index);

	return 0;
}
//�ҵ��Ӵ� 
int StrIndex(char *s,char *t)
{
	int i=0,j=0;
	int slen;
	int tlen;
	slen=strlen(s); 
	tlen=strlen(t); 
	while(i<slen&&j<tlen){
		if(s[i]==t[j]){
			i++;
			j++;
		}else{
			i=i-j+1;
			j=0;
		}
	}
	if(j==tlen){
			return (i-tlen);
		}else{
			return -1;
		}
}

void deleOnestr(char * a ,char *b){
	int index;
	int len;
	len=strlen(b);
	index=StrIndex(a,b);
}

void delestr(char * a ,char *b){
	
}

float  mystof(char *str)
{
	int flag=1;
	float num=0;
	int count=0;
	int clark;
	while(*str!='\0')
	{
	
	//�ж�������
		if(*str=='-'){
		flag=-1;
		str++;
		}
		//�ж��Ƿ����С����
		if(*str=='.'){
		clark=1;
		str++;
		}
		if(clark==1){
		count++;
		}
		if( (*str>='0') && (*str<='9') )//�ж��Ƿ����ַ�1��9֮��
		num=num*10+(*str-'0');
		str++;
		}
	num=flag*num*pow(10,-count);
	return num;
}



void  maxword(char * s)
{
	int leng=0;
	int i,j;
	int max=0;
	char *index;//��¼��ַ 
	index=s; 
	while(*index!='\0'){
		//ÿһ�����ʽ��в������� 
		while((*index>='A'&&*index<='Z') ||(*index>='a'&&*index<='z')){
			leng++;
			index++;
		}
		if(max<leng){
			max=leng;
			s=index-leng;
		} 
		leng=0;
		//�����ǵ����ַ� 
		index++;
	}
	for(i=0;i<max;i++){
			printf("%c",s[i]);
	}
	printf("\n");
	printf("�:%d",max);
}
