/* run this program using the console pauser or add your own getch, system("pause") or input loop */

#include <iostream>
#include <stdio.h>
#define N 4
#define MaxSize 100

typedef struct tupnode
{int r;    //�к�
int c;   //�к�
int d;   //��ֵ
}TupNode;

typedef struct matrix
{TupNode data[MaxSize];
 int rows=0;   //������
 int cols=0;    //������
 int nums=0;    //��0Ԫ���ܸ���
}TSMatrix;

void CreatMat(TSMatrix* t,int a[N][N])
{int i,j;
 t->rows=N;//�� 
 t->cols=N;//�� 
 	//printf("%d\n",t->nums);
 	
 for(i=0;i<N;i++)
	 for(j=0;j<N;j++)
		 if(a[i][j]!=0)
		 {
		  t->data[t->nums].r=i;
		  t->data[t->nums].c=j;
		  t->data[t->nums].d=a[i][j];
		  (t->nums)++;//��0��ʼ++ 
		 }
}

void DispMat(TSMatrix* t)
{	int i;
	 if(t->nums<=0)
		 return;
//	 cout<<t.rows<<' '<<t.cols<<' '<<t.nums<<endl;
//	 cout<<"-----------------------"<<endl;
	 for(i=0;i<t->nums;i++){
	 	printf("r=%d c=%d d=%d\n",t->data[i].r,t->data[i].c,t->data[i].d);
	 }
}
//{1,0,3,0},
//{0,1,0,0},
//{0,0,1,0},
//{0,0,1,1}
//r=0 c=0 d=1
//r=0 c=2 d=3
//r=1 c=1 d=1
//r=2 c=2 d=1
//r=3 c=2 d=1
//r=3 c=3 d=1
void TranMat(TSMatrix* tsa,TSMatrix *tsc)
{
	int p,q=0,v;
	 tsc->rows=tsa->cols;
	 tsc->cols=tsa->rows;
	 tsc->nums=0;
	 if(tsa->nums!=0)
	 {for(v=0;v<tsa->cols;v++) //��  
	   for(p=0;p<tsa->nums;p++) //��0Ԫ���ܸ��� 
		   if(tsa->data[p].c==v)//c:�� v���� 
		   {tsc->data[tsc->nums].c=tsa->data[p].r;
		    tsc->data[tsc->nums].r=tsa->data[p].c;
			tsc->data[tsc->nums].d=tsa->data[p].d;
			p++;
			tsc->nums++;
		   }
	 }
}
//
//void DispNN(TSMatrix t)
//{	
//	int i,j,k,flag;
//	 for(i=0;i<t.rows;i++)
//	   {for(j=0;j<t.cols;j++)
//	     {
//		  flag=0;
//	      for(k=0;k<t.nums;k++)
//		    if((i==t.data[k].r)&&(j==t.data[k].c))
//			{cout<<t.data[k].d<<' ';
//	         flag=1;
//	         break;
//	        }
//	      if(flag==0)
//	         cout<<"0"<<' ';
//	      }
//	     cout<<endl;
//	    }
//}

int main()
{	int a[N][N]={{1,0,3,0},{0,1,0,0},{0,0,1,0},{0,0,1,1}};
		int i,j;
	 TSMatrix tsa,tsc;
	 //printf("%d\n",tsa.nums);
	 CreatMat(&tsa,a);//����1�����ṹ��ָ�� 
//	 for(i=0;i<tsa.nums;i++){
//	 	printf("%d==%d\n",i,tsa.data[i].d);
//	 }
	 //cout<<"a����Ԫ��Ϊ��"<<endl;
	 
//	 printf("a����Ԫ��Ϊ��\n");
	 DispMat(&tsa);
	 
//	 cout<<"aת�ú����Ԫ��Ϊ��"<<endl;
	printf("aת�ú����Ԫ��Ϊ��\n");
	//DispMat(&tsa);	
	 TranMat(&tsc,&tsa);
	 DispMat(&tsa);
//	 cout<<"aת�ú�Ľ������Ϊ��"<<endl;
//	 DispNN(tsc);
	return 0;
}

