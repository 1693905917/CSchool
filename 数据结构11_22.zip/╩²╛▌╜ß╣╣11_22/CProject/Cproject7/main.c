#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
double mystof(char *s) {
    return strtod(s, NULL);
}
int main(int argc, char *argv[]) {
	void  maxword(char  * s );
	//float  mystof(char *str);
	void delestr(char * a ,char *b);
	int StrIndex(char *s,char *t);
	void deleteSubStr(char *str,char *substr);
	void replstr(char * a ,char *b,char *c);
	//7.1 
//	char *s="I am a students,She is a physician";
//	maxword(s);
	
	//7.2
	//    char s[] = "123.23";
//    double num = mystof(s);
//    printf("%f\n", num); // �����123.230000


//	char s[]="123.23";
//	float f=mystof(s);
//	printf("%f",f);


	//7.3
//	char s[]="aaaabcaabca";
//	char t[]="bc";
//	char a[]="123"; 
//	deleteSubStr(s,t);
//    printf("%s",s);
    //7.4
    char s[]="abcabcabc";
	char t[]="ab";
	char a[]="aa"; 
	replstr(s,t,a);
	printf("%s\n", s); 
	return 0;
}
//���������Ӵ� 
void replstr(char * a ,char *b,char *c)
{
	int lena = strlen(a);
    int lenb = strlen(b);
    int lenc = strlen(c);
    char temp[1000];
    int i, j, k, flag;
    for (i = 0, k = 0; i < lena; ) {
        flag = 1;
        for (j = 0; j < lenb; j++) {
            if (a[i+j] != b[j]) {
                flag = 0;
                break;
            }
        }
        if (flag) {
            for (j = 0; j < lenc; j++) {
                temp[k++] = c[j];
            }
            i += lenb;
        } else {
            temp[k++] = a[i++];
        }
    }
    temp[k] = '\0';
    strcpy(a, temp);
//	char *p;
//    while ( p=strstr(a,b) )
//        memcpy(p,c,strlen(c));
//    printf("%s\n", a );
} 
//ɾ�������Ӵ� 
void deleteSubStr(char *str,char *substr)
{
	int i,pos;
    int len1=strlen(str),len2=strlen(substr);
    while(strstr(str,substr))
    {
        pos=strstr(str,substr)-str;
        for(i=pos;i<len1-len2;++i)
        {
            str[i]=str[i+len2];
        }
        len1-=len2;
        str[len1]='\0';
    }
}
//�ҵ��Ӵ� 
int StrIndex(char *s,char *t)
{
	int i=0,j=0;
	int slen;
	int tlen;
	slen=strlen(s); 
	tlen=strlen(t); 
	while(i<slen&&j<tlen){
		if(s[i]==t[j]){
			i++;
			j++;
		}else{
			i=i-j+1;
			j=0;
		}
	}
	if(j==tlen){
			return (i-tlen);
		}else{
			return -1;
		}
}


//float  mystof(char *str)
//{
//	int flag=1;
//	float num=0;
//	int count=0;
//	int clark;
//	while(*str!='\0')
//	{
//	
//	//�ж�������
//		if(*str=='-'){
//		flag=-1;
//		str++;
//		}
//		//�ж��Ƿ����С����
//		if(*str=='.'){
//		clark=1;
//		str++;
//		}
//		if(clark==1){
//		count++;
//		}
//		if( (*str>='0') && (*str<='9') )//�ж��Ƿ����ַ�1��9֮��
//		num=num*10+(*str-'0');
//		str++;
//		}
//	num=flag*num*pow(10,-count);
//	return num;
//}



void  maxword(char * s)
{
	int leng=0;
	int i,j;
	int max=0;
	char *index;//��¼��ַ 
	index=s; 
	while(*index!='\0'){
		//ÿһ�����ʽ��в������� 
		while((*index>='A'&&*index<='Z') ||(*index>='a'&&*index<='z')){
			leng++;
			index++;
		}
		if(max<leng){
			max=leng;
			s=index-leng;
		} 
		leng=0;
		//�����ǵ����ַ� 
		index++;
	}
	for(i=0;i<max;i++){
			printf("%c",s[i]);
	}
	printf("\n");
	printf("�:%d",max);
}
