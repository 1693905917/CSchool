#include <iostream.h>
#define N 4
#define MaxSize 100

typedef struct tupnode
{int r;
 int c;
 int d;
}TupNode;

typedef struct matrix
{TupNode data[MaxSize];
 int rows;
 int cols;
 int nums;
}TSMatrix;

void CreatMat(TSMatrix t,int a[N][N])
{int i,j;
 t.rows=N;
 t.cols=N;
 for(i=0;i<N;i++)
	 for(j=0;j<N;j++)
		 if(a[i][j]!=0)
		 {t.data[t.nums].r=i;
		  t.data[t.nums].c=j;
		  t.data[t.nums].d=a[i][j];
		  t.nums++;
		 }
}

void DispMat(TSMatrix t)
{int i;
 if(t.nums<=0)
	 return;
 cout<<t.rows<<' '<<t.cols<<' '<<t.nums<<endl;
 cout<<"-----------------------"<<endl;
 for(i=0;i<t.nums;i++)
   cout<<t.data[i].r<<' '<<t.data[i].c<<' '<<t.data[i].d<<endl;
}

void TranMat(TSMatrix tsa,TSMatrix &tsc)
{int p,q,v;
 tsc.rows=tsa.cols;
 tsc.cols=tsa.rows;
 tsc.nums=tsa.nums;
 if(tsa.nums!=0)
 {for(v=0;v<tsa.cols;v++)
   for(p=0;p<tsa.nums;p++)
	   if(tsa.data[p].c==v)
	   {tsc.data[q].c=tsa.data[p].r;
	    tsc.data[q].r=tsa.data[p].c;
		tsc.data[q].d=tsa.data[p].d;
		p++;
	   }
 }
}

void DispNN(TSMatrix t)
{int i,j,k,flag;
 for(i=0;i<t.rows;i++)
   {for(j=0;j<t.cols;j++)
     {flag=0;
      for(k=0;k<t.nums;k++)
	    if((i==t.data[k].r)&&(j==t.data[k].c))
		{cout<<t.data[k].d<<' ';
         flag=1;
         break;
         }
      if(flag==0)
         cout<<"0"<<' ';
      }
     cout<<endl;
    }
}

void main()
{int a[N][N]={{1,0,3,0},{0,1,0,0},{0,0,1,0},{0,0,1,1}};
 TSMatrix tsa,tsc;
 CreatMat(tsa,a);
 cout<<"a����Ԫ��Ϊ��"<<endl;
 DispMat(tsa);
 cout<<"aת�ú����Ԫ��Ϊ��"<<endl;
 TranMat(tsc,tsa);
 DispMat(tsc);
 cout<<"aת�ú�Ľ������Ϊ��"<<endl;
 DispNN(tsc);}

