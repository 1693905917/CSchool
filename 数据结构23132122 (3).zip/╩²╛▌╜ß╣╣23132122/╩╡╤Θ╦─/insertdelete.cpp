#include <stdio.h>
#include <stdlib.h>

typedef struct chain {
    char data;              
    struct chain *next;       
} jd;

jd *circulachain(jd *head, char x, char y) {
    jd *newNode = (jd*)malloc(sizeof(jd)); 
    newNode->data = y;        
    newNode->next = head;      
    
    if (head != NULL) {
        head->next = newNode;  
        newNode->next = head;  
    }
    return newNode;
}

void showxydata(jd *head) {
    jd *current = head;
    while (current != current->next) {  
        printf("%c ", current->data);  
        current = current->next;  
    }
    printf("\n");  
}
int main() {
    jd *head = (jd*)malloc(sizeof(jd));   // ��ʼ���׽��
    head->data = 'A';                       // �׽������ΪA
    head->next = NULL;                     // �׽��û����һ���ڵ�
    
    
    head = circulachain(head, 'H', 'H');  
    
    
    showxydata(head);  // ��ʾѭ�������е����нڵ�����
  
    return 0;
}
