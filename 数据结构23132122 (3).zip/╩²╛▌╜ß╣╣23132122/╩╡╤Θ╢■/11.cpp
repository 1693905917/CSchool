#include "stdio.h" 
typedef struct chain{
                   char  data;
                   struct chain *next;
           }jd;

