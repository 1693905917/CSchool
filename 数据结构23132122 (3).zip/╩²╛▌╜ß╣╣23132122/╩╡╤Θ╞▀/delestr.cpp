#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void delestr(char *a, char *b) {
    int lena = strlen(a);
    int lenb = strlen(b);
    int i, j, k;
    for (i = 0; i <= lena - lenb; i++) {
        for (j = i; j < i + lenb; j++) {
            if (a[j] != b[j - i]) {
                break;
            }
        }
        if (j == i + lenb) {
            for (k = i; k < lena - lenb; k++) {
                a[k] = a[k + lenb];
            }
            a[k] = '\0';
            i--;
            lena = strlen(a);
        }
    }
}
int main(){
	char a[1000] = "hello world, world is beautiful!";
	char b[100] = "world";
	delestr(a,b);
	printf("%s\n", a);//�����hello ,  is beautiful!
}
