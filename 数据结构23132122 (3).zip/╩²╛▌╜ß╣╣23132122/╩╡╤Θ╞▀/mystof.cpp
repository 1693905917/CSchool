#include <stdio.h>
#include <stdlib.h>

double mystof(char *s) {
    return strtod(s, NULL);
}

int main() {
    char s[] = "123.23";
    double num = mystof(s);
    printf("%f\n", num); // �����123.230000
    return 0;
}

