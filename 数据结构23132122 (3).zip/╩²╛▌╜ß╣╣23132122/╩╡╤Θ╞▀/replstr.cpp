#include <stdio.h>
#include <string.h>

void replstr(char *a, char *b, char *c) {
    int lena = strlen(a);
    int lenb = strlen(b);
    int lenc = strlen(c);
    char temp[1000];
    int i, j, k, flag;
    for (i = 0, k = 0; i < lena; ) {
        flag = 1;
        for (j = 0; j < lenb; j++) {
            if (a[i+j] != b[j]) {
                flag = 0;
                break;
            }
        }
        if (flag) {
            for (j = 0; j < lenc; j++) {
                temp[k++] = c[j];
            }
            i += lenb;
        } else {
            temp[k++] = a[i++];
        }
    }
    temp[k] = '\0';
    strcpy(a, temp);
}
int main(){
	char a[1000] = "hello world, world is beautiful!";
	char b[100] = "world";
	char c[100] = "universe";
	replstr(a, b, c);
	printf("%s\n", a); // �����hello universe, universe is beautiful!
} 
