#include<stdio.h>
#include<string.h>
//�ж���ĸ
int word(char a){
	if ((a <= 'z' && a>='a') || (a <= 'Z' && a>='A')) {
		return 1;
	}
	else
	{
		return 0;
	}
}
//�ҵ���
void  maxword(char *s) {
	int len=0;//����
	int maxlen=0;//���
	int sign=0;//���λ��  
	int x=0;
	for (int  i = 0; i<=strlen(s); i++)
	{
		if (word(s[i])) {
			len++;
		}
		else
		{
			if (len>maxlen) {
				maxlen = len;
				sign = i -maxlen;
				len = 0;
			}
			len = 0;
		}
	}
	for (int k = 0; k <=maxlen; k++)
	{
		printf("%c", s[sign + k]);
		x++;
	}
	printf("����Ϊ��%d",x-1);
}
int main()
{
	char a[] = "I am a student,She is a physician";
	maxword(a);
	return 0;
}

