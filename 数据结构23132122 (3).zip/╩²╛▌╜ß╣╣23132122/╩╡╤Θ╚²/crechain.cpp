#include <stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct chain{
					char data;
					struct chain *next;
				}jd;

int main(int argc,char *argv[]){
	jd *head;
	char ch[]="ABCDEFGH";
	jd *crechain(char *ch,int n);
	void showdata(jd *head);
	
	head=crechain(ch,strlen(ch));
	showdata(head);
	return 0;
}

void showdata(jd *head){
	if(head==NULL){
		return;
	}
	while(head!=NULL){
		printf("%c \t",head->data);
		head=head->next;
	}
}

jd *crechain(char *ch,int n){
	jd *head;
	jd *temp;
	int i;
	if(n<=0){ //�ж�ch�Ƿ�Ϊ�� 
		return NULL;
	}
	else if(n==1){
		head=(jd*)malloc(sizeof(jd));
		temp=head;
		head->data=*(ch+n-1);
		head->next=NULL;
		return temp;
	} 
	else{
		head=(jd*)malloc(sizeof(jd));
		temp=head;
		head->data=*(ch+n-1);
		head->next=NULL;
		
		for(i=n-2;i>=0;i--){
			head=(jd*)malloc(sizeof(jd));
			head->data=*(ch+i);
			head->next=temp;
			temp=head;
		}
		return temp;
	}
	
}
