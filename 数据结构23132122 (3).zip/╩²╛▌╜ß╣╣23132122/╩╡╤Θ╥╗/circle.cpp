#include "stdio.h" 
#include<math.h>
main()
{
	float r,dd,area;
	float circle(float r,float *d);
	r=10.0;
	area = circle(r, &dd);
    printf("Radius: %.2f\n", r);
    printf("Area: %.2f\n", area);
    printf("Circumference: %.2f\n", dd);
    return 0;
}
float circle(float r,float *d){
	float area=M_PI*r*r;
	*d=2*M_PI*r;
	return area; 
}
