#include "stdlib.h"
#include "stdio.h"
typedef struct chain{
                   char  data;
                   struct jd *next;
           }jd;
main(){
	char b[]="ABCDEFGH";
	chain *crechain(char *ch,int n);
	void showdata(jd *head);
}
 chain *crechain(char *ch,int n){
 	jd *p,*q,head;
 	if(n==0) 
	 return NULL;
 	q=crechain(ch+1,n-1);
 	p=(jd*)malloc(sizeof(jd));
 	p->data=ch[0];
 	p->next=q;
 	return head;
 }
 void showdata(jd *head){
 	jd *p;
 	p=head->link;
 	printf("\n");
 	while(p!=NULL){
 		printf("%c   ",p->data);
 		p=p->next;
	 }
 	
 	
 }
