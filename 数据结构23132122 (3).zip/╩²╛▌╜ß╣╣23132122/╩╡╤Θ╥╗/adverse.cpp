#include "stdio.h" 
#include "string.h"
main()
{
  char s[ ]= "123ABC" ,*p;
  void adverse(char * a );
  p=s;
  adverse(p);
  printf(" \n\n%s\n",s);
}
   void adverse(char * a )
{
    char *p = a;
    char *q = a + strlen(a) - 1;
    while (p < q) {
        char temp = *p;
        *p++ = *q;
        *q-- = temp;
    }
}

