#include "stdio.h" 

main()
{
  float r,ss,dd;
  void mycircle(float r,float *s,float *d);
  r=10;
  mycircle(r,&ss,&dd);
printf("radius=%.2f area=%.2f  cicum=%.2f\n",r,ss,dd);
}
 void mycircle(float r,float *s,float *d)
   {
   		
    	*s=3.14 * r * r;
    	*d=2.0 * 3.14 * r;
   }

