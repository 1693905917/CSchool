#include "stdio.h"
main(){
	int x=1,y=2;
	void swap(int *a,int *b);
	printf("Before swap: x = %d, y = %d\n", x, y);
    swap(&x, &y);
    printf("After swap: x = %d, y = %d\n", x, y);
    return 0;
}
void swap(int *a,int *b){
	int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}
