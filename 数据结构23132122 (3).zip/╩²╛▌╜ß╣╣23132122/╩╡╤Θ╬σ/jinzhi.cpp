#include "stdio.h"
#include <string.h>

typedef struct stack{
    char data[100];
    int top;
}sqstk;

void push(sqstk *s, char x){
    if(s->top == 99){
        printf("Stack is full!\n");
        return;
    }
    s->data[++s->top] = x;
}

char pop(sqstk *s){
    if(s->top == -1){
        printf("Stack is empty!\n");
        return '\0';
    }
    return s->data[s->top--];
}

int main(){
	sqstk s;
	s.top = -1;
	int n;
	printf("������һ��ʮ��������");
	scanf("%d", &n);
	while(n != 0){
	push(&s, n%2+'0');
	n /= 2;
	}
	printf("ת��Ϊ��������Ϊ��");
	while(s.top != -1){
	printf("%c", pop(&s));
	}
	printf("\n");
}
