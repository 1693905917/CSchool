#include "stdio.h"
#include <string.h>

typedef struct stack{
    char data[100];
    int top;
}sqstk;

void push(sqstk *s, char x){     //��ջ 
    if(s->top == 99){
        printf("Stack is full!\n");
        return;
    }
    s->data[++s->top] = x;
}

char pop(sqstk *s){          //��ջ 
    if(s->top == -1){
        printf("Stack is empty!\n");
        return '\0';
    }
    return s->data[s->top--];
}

int main(){
    sqstk s;
    s.top = -1;
    char str[100];
    printf("������һ���ַ���");
    scanf("%s", str);
    for(int i=0; i<strlen(str); i++){
        push(&s, str[i]);
    }
    printf("��һ���ַ�������Ϊ�� ");
    while(s.top != -1){
        printf("%c", pop(&s));
    }
    printf("\n");
    return 0;
}

