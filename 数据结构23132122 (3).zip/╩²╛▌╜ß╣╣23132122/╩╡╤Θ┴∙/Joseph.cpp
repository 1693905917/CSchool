#include <stdio.h>
#include <stdlib.h>

typedef struct node {
    int data;
    struct node *next;
} Node;

typedef struct queue {
    Node *front;
    Node *rear;
} Queue;

void initQueue(Queue *q) {
    q->front = q->rear = (Node*)malloc(sizeof(Node));
    q->front->next = NULL;
}

int isEmpty(Queue *q) {
    return q->front == q->rear;
}

void enQueue(Queue *q, int data) {
    Node *newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->next = NULL;
    q->rear->next = newNode;
    q->rear = newNode;
}

int deQueue(Queue *q) {
    if (isEmpty(q)) {
        printf("Queue is empty!\n");        exit(1);
    }
    Node *p = q->front->next;
    int data = p->data;
    q->front->next = p->next;
    if (q->rear == p) {
        q->rear = q->front;
    }
    free(p);
    return data;
}

void Joseph(int n, int k, int m) {
    Queue q;
    initQueue(&q);
    int i;
    for (i = 1; i <= n; i++) {
        enQueue(&q, i);
    }
    for (i = 1; i < k; i++) {
        enQueue(&q, deQueue(&q));
    }
    while (!isEmpty(&q)) {
        for (i = 1; i < m; i++) {
            enQueue(&q, deQueue(&q));
        }
        printf("%d ", deQueue(&q));
    }
}

int main() {
    int n, k, m;
    printf("Please input n, k, m: ");
    scanf("%d%d%d", &n, &k, &m);
    Joseph(n, k, m);
    return 0;
}

